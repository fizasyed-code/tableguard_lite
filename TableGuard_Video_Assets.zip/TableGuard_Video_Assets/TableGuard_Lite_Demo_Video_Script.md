# TableGuard-Lite — 60–90 Second Demo Video Script

## Recommended length: 85 seconds

### 0–7 s — Hook
**Visual:** final table layout + short title card.

**On-screen text:**
`TABLEGUARD-LITE`
`Verifiable Bimanual Physical AI`

**Voiceover:**
“Vision-language robot policies can generate plausible actions, but plausible does not always mean physically safe.”

---

### 7–15 s — Task
**Visual:** top camera view showing plate, fork, cup, and both arms.

**On-screen text:**
`Natural-language table setting`
`Cup → right | Fork → left | Plate preserved`

**Voiceover:**
“TableGuard-Lite turns a natural-language table-setting command into coordinated dual-arm execution using three cameras and robot proprioception.”

---

### 15–32 s — Complete physical reference
**Visual:** accelerated successful 08ZA reference sequence.

**On-screen text:**
`FULL PHYSICAL REFERENCE EXECUTION — PASSED`
`Right arm: grasp • lift • +25 mm • place • release`
`Left arm: grasp • 25 mm table slide • release`

**Voiceover:**
“Our complete physical reference passes end-to-end: the right arm places the cup, the left arm moves the fork with a table-supported slide, and the plate remains preserved.”

**Small footer:**
`Reference/controller evidence — not learned VLA execution`

---

### 32–48 s — Learned SmolVLA
**Visual:** three synchronized camera views and learned rollout clip.

**On-screen text:**
`3 RGB cameras + 12-joint state + language`
`SmolVLA closed-loop execution`

**Voiceover:**
“The learned policy receives top and wrist RGB views, all 12 joint positions, and language. A 9,901-update specialist performs local approach and collision-recovery behavior.”

---

### 48–61 s — Safety / verification
**Visual:** overlay arrows from policy to safety layer to robot; include a guard-stop frame or log line.

**On-screen text:**
`RUNTIME PHYSICAL AUTHORIZATION`
`0.35 rad/s slew • contact guard • preservation checks • trace logging`

**Voiceover:**
“Crucially, model outputs do not directly control the robot. Every action passes through explicit physical authorization, and unsafe contact stops execution instead of being hidden.”

---

### 61–75 s — Intel/OpenVINO
**Visual:** simple metric card.

**On-screen text:**
`Verified Intel/OpenVINO deployment proof`
`PyTorch CPU   936.151 ms`
`OpenVINO CPU  673.520 ms`
`1.39× faster | 28.1% lower median latency`

**Voiceover:**
“An earlier verified TableGuard checkpoint also runs through OpenVINO on an Intel i7-13700K CPU, reducing median inference latency by 28.1 percent with near-identical outputs.”

**Small footer:**
`Earlier verified checkpoint deployment proof`

---

### 75–85 s — Close
**Visual:** architecture diagram + final robot/table image.

**On-screen text:**
`FROM AI-GENERATED ACTIONS`
`TO PHYSICALLY AUTHORIZED ACTIONS`

**Voiceover:**
“TableGuard-Lite is not just a robot policy. It is a verifiable execution stack for safer Physical AI.”

---

## Editing rules
- Keep labels large and readable.
- Never label the full scripted/reference run as learned VLA execution.
- Show at least one frame with all three cameras.
- Keep the Intel/OpenVINO card on screen for at least 5 seconds.
- Use the same navy/cyan visual identity as the pitch deck.
- Avoid long terminal output; crop to one useful guard or metric line.
